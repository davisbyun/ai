package javaBasic.ch04.sec01;

public class While������ {

	public static void main(String[] args) {
		int a = 0;
//		while(a<10) {
//			a=a+2;
//			System.out.println(a);
//		}
//		do {
//			a=a+1;
//			System.out.println(a);
//		}
//		while(a<10);
//		a = 11;
//		do {
//			a=a-1;
//			System.out.println(a);
//		}
//		while(a>1);
//		a=0;
//		do {
//			a=a+2;
//			System.out.println(a);
//		}
//		while(a<20);
//		a=0;
//		do {
//			a=a+5;
//			System.out.println(a);
//		}
//		while(a<100);
//		for(int i=1; i<=10; i=i+1) {
//			System.out.println(i);
//		}
//		for(int i=1; i<=50; i=i+1) {
//			System.out.println(i);
//		}
//		for(int i=50; i>=1; i=i-1) {
//			System.out.println(i);
//		}
//		for(int i=1, j=11; i<=10 || j<=20; i=i+1, j=j+1) {
//			System.out.println(i + " " + j);
//		}
//		for(int i=1, j=100, k=201; i<=100 || j>=1 || k<=300; i=i+1, j=j-1, k=k+1) {
//			System.out.println(i + " " + j + " " + k);
//		}
//		for(int i = 1; i<4; i=i+1) {
//			System.out.println(i);
//			for(int j=i; j<i+2; j=j+1) {
//				System.out.print(j + " ");
//			}
//			System.out.println();
//		}
		
		for(int i = 10; i<=11; i=i+1) {
			System.out.println(i);
			for(int j=i; j>=i-2; j=j-1) {
				System.out.print(j + " ");
			}
			System.out.println();
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}

package javaBasic.ch04.sec01;

import java.util.Scanner;

public class Switch�� {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
//		System.out.println("���� ù���� �Է��ϱ�");
//		String word = sc.next();
//		System.out.println(word);
		
//		if(word.equals("A")) {
//			System.out.println("Apple");
//		}
//		else if(word.equals("B")) {
//			System.out.println("Bear");
//		}
//		else if(word.equals("C")) {
//			System.out.println("Cat");
//		}
//		else {
//			System.out.println("�ٽ� �Է�");
//		}
//		switch(word) {
//		case "A": System.out.println("Apple");
//		break;
//		case "B": System.out.println("Bear");
//		break;
//		case "C": System.out.println("Cat");
//		break;
//		default : System.out.println("�ٽ� �Է�");
//		}
//		System.out.println("���ڸ� �Է��ϼ���");
//		int number = sc.nextInt();
//		if(number>=0 & number<1000) {
//			int number100 = number/100;
//			int number10 = (number - number100*100)/10;
//			int number1 = number - number100*100 - number10*10;
//			System.out.println("100�� �ڸ� : " + number100);
//			System.out.println("10�� �ڸ� : " + number10);
//			System.out.println("1�� �ڸ� : " + number1);
//		}
//		else {
//			System.out.println("�ٽ��Է�");
//		}
		
		
	}

}

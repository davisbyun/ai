package javaBasic.ch04.sec01;

public class For�� {

	public static void main(String[] args) {
		
	}

}

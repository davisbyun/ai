package javaBasic.ch04.sec01;

public class Ȯ�ι���4�� {

	public static void main(String[] args) {
//		int sum =0;
//		for(int i=1; i<=100; i=i+1) {
//			if(i%3==0) {
//				sum = sum + i;
//			}
//		}
//		System.out.println(sum);
//		for(int x = 1; x<=10; x=x+1) {
//			for(int y = 1; y<=10; y=y+1) {
//				if(4*x+5*y==60) {
//					System.out.println(x + " " + y);
//				}
//			}
//		}
//		for(int i=1; i<6; i=i+1) {
//			for(int j=1; j<=i; j=j+1) {
//				System.out.print("*");
//			}
//			System.out.println();
//		}
		
	}

}

package javaBasic.ch04.sec01;

public class IF�� {

	public static void main(String[] args) {
//		int score = 87;
//		if(score >=90) {
//			System.out.println("A");
//		}
//		if(score>=80 && score<90) {
//			System.out.println("B");
//		}
//		if(score>=70 && score<80) {
//			System.out.println("C");
//		}
		
//		int d = 10;
//		double e = 10 % 0.0;
//		boolean f = false;
//		if(d!=0 && Double.isNaN(e) && f == false) {
//			System.out.println("�߸��� �ڵ��Դϴ�");
//		}
//		else {
//			System.out.println("�Ḣ�� �ڵ��Դϴ�");
//		}
//		boolean ok = false;
//		if(false) {
//			System.out.println("�հ�");
//		}
//		else {
//			System.out.println("���հ�");
//		}
//		int number = 1;
//		if(number==3) {
//			System.out.println("��");
//		}
//		else if(number==2){
//			System.out.println("��");
//		}
//		else if(number==1){
//			System.out.println("��");
//		}
//		else if(number==4){
//			System.out.println("��");
//		}
		
		
	}

}

package javaBasic.ch03.sec01;

public class ���������� {

	public static void main(String[] args) {
//		boolean b1 = true;
//		boolean b2 = false;
//		
////		System.out.println(b1 && b2);
////		System.out.println(b1 || b2);
////		System.out.println(b1 ^ b2);
////		System.out.println(!b2);
//		
//		byte b3=10;
//		byte b4=7;
//		System.out.println(b3 & b4);
//		System.out.println(b3 | b4);
//		System.out.println(b3 ^ b4);
////		1110
////		0.0100
//		int count = 100;
////		count = count + 10;
//		count += 10;
//		int score = 85;
//		String result = (score >= 90) ? "���л�" : "�����л�";
//		System.out.println(result);
//		int avg = 90;
//		int total = 21300;
//		String result = (avg > 85.8 && total >= 1400) ? "���" : "����";
//		System.out.println(result);
//		String name = "�����";
//		String result = name == "�����" || name == "�̼��� " || name == "�ּ���" ? "ģ����!" : "�ȳ��ϼ���";
//		System.out.println(result);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}

package javaBasic.ch03.sec02;

public class Ȯ�ι���3�� {

	public static void main(String[] args) {
//1��	int x = 10;
//		int y = 20;
//		int z = ++x + y--;
//		System.out.println(z);
		
//2��	int score = 85;
//		String result = ((score>90)) ? "��" : "��";
//		System.out.println(result);
		
//3��	int pencils = 534;
//		int students =30;
//		
//		int pencilsPerStudent = pencils/students;
//		System.out.println(pencilsPerStudent);
//		
//		int pencilsLeft = pencils%students;
//		System.out.println(pencilsLeft);
		
//		int value = 356;
//		System.out.println(value/100*100);
		
//		int lengthTop = 5;
//		int lengthBottom = 10;
//		int height = 7;
////		double area = (lengthTop+lengthBottom)*height/2.0;
////		double area = (lengthTop+lengthBottom)*height*1.0/2;
////		double area = (double)(lengthTop+lengthBottom)*height/2;
//		double area = (double)((lengthTop+lengthBottom)*height/2);
//		System.out.println(area);
		
		double x = 5.0;
		double y = 10.0;
		double z = 5%y;
		System.out.println(x>7&&y<=5);
		System.out.println(x%3==2||y%2!=1);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}

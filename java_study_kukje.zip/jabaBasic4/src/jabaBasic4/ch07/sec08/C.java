package jabaBasic4.ch07.sec08;

//import jabaBasic4.ch07.sec07.A;

public class C {

//	public void method () {
//		
//		A a = new A();
//		a.field = "value";
//		a.method();
	}


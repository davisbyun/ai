package jabaBasic4.ch07.sec11;

public class Promotion3 {

	public static void main(String[] args) {

//		System.out.println("--------------");
//		A = new A();
//		a.eat();
//		B b = new B();
//		A b1 = new B();
//		b.eat();
//		b1.eat(); //
//		
//		System.out.println("--------");
//		
//		C c = new C();
//		
		
		
		
	}
	
	class A {
		
		void eat() {
			System.out.println("��");
		}
		
		
		class B extends A {	
			@Override
			void eat() {
	
			}
		}	
		
				
		class BB extends A{
			@Override
			void eat() {
	
			}
	}
		
	}
	}
	

		

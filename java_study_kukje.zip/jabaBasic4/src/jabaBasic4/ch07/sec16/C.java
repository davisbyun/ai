package jabaBasic4.ch07.sec16;

public class C {

	public void method1() {
		System.out.println("C-Method1()");
	public void method2() {
		System.out.println("C-Method2()");
		
	}	
}

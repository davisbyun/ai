package jabaBasic4.ch07.sec16;

public class MainActivity extends Activity {

	public static void main(String[] args) {
		
		@override
		public void onCreate() {
		  super.onCreate();
		  
		}

	}

}


package jabaBasic4.ch07.sec16;

public class A {

	public void method1() {
		System.out.println("C-Method1()");
		
	}
}

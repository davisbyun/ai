package jabaBasic4.ch07.sec16;

public class B extends A {
	
	public void method1() {
		System.out.println("C-Method1()");
}
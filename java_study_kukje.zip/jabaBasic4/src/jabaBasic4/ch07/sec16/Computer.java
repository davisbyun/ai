package jabaBasic4.ch07.sec16;

public class Computer extends Machine {

}

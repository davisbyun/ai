package jabaBasic4.ch07.sec16;

public class Ȯ�ι���7�� {
	//1)1,2)2,3)1,4)4,5)2,(6,7,8)���� ,9)2, 11)super, 12) ((C) a).method2
	public static void main(String[] args) {
		
		public static void action(A a) {
			a.method1();
		}
		
		action(new a());
		
	}

}

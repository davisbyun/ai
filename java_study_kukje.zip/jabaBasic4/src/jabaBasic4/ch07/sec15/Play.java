package jabaBasic4.ch07.sec15;

public class Play {
	
	void playing(Phone phone ) {
		phone.turnOn();
	}
	void stop(Phone phone) {
		phone.turnOff();
	}
}

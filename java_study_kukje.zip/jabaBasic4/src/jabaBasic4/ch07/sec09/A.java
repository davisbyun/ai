package jabaBasic4.ch07.sec09;

public class A {

}

class B extends A {
	
}

class c extends A {
		
}

class D extends B {
	
}

class E extends C {
	
}


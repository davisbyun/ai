package jabaBasic4.ch07.sec14;

public class Taxi extends Vehicle {

	@Override
	public void run() {
		System.out.println("�ýð� �޸��ϴ�.");
    }
}
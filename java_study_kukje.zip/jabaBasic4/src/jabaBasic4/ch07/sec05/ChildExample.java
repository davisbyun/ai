package jabaBasic4.ch07.sec05;

public class ChildExample {

	public static void main(String[] args) {
		
		Child child = new Child();
	}

}

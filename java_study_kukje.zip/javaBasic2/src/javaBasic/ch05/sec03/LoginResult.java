package javaBasic.ch05.sec03;

public enum LoginResult {
	LOGIN_SUCCESS,
	LOGIN_FAILED

}

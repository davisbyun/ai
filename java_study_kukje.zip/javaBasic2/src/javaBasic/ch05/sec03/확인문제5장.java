package javaBasic.ch05.sec03;

import java.util.Iterator;

public class Ȯ�ι���5�� {

	public static void main(String[] args) {
		int[] array = {1,5,3,8,2};
//		int max = 0;
//		for (int i = 0; i < array.length; i++) {
//			if(max < array[i]) {
//				max = array[i];
//			}
//		}
//		System.out.println(max);
//		for (int i = 0; i < array.length; i++) {
//			for (int j = i+1; j < array.length; j++) {
//				if(array[i]>array[j]==false) {
//					
//					break;
//				}
//			}
//		}
//		int sum = 0;
//		double c = 0;
//		int[][] array = {{95,86},{83,92,96},{78,83,93,87,88}};
//		for (int i = 0; i < array.length; i++) {
//			for (int j = 0; j < array[i].length; j++) {
//				sum = sum + array[i][j];
//				c = c+1;
//			}
//		}
//		System.out.println(sum);
//		System.out.println(sum/c);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}

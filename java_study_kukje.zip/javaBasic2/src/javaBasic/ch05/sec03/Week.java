package javaBasic.ch05.sec03;

public enum Week {
	MONDAY,
	TUESDAY,
	WEDNESDAY,
	THURSDAY,
	FIRDAY,
	SATURDAY,
	SUNDAY

}

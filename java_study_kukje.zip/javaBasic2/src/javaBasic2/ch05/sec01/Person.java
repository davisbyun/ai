package javaBasic2.ch05.sec01;

public class Person {
	
}

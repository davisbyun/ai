package javaBasic2.ch05.sec01;

public class Student {
	String name;
	int kor;
	
}

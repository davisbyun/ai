package javaBasic2.ch05.sec01;

public class Teacher {
	String name;
	String dept;
	int pay;

}

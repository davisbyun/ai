package javaBasic2.ch05.sec02;

public class A {
	String name;
	int kor;
	double avg;
}

package javaBasic2.ch05.sec02;

public class B {
	String name;
	boolean ox;
	public B(String name) {
		this.name = name;
	}
}

package javaBasic3.ch06.sec006;

public class �޼ҵ� {
	
	void m1() {
		
	}
	
	int m2() {
		return 0;
	}
	
	double m3(int...values) {
		return 0;
	}
	
	double sum(double...values) {
		return 0.0;
	}
	
	double sum(int...values) {
		return 0;
	}
	
	String sum(String...values) {
		return null;
	}
	
	String sum(boolean...values) {
		return null;
	}
}

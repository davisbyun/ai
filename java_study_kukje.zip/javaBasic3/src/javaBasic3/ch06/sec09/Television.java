package javaBasic3.ch06.sec09;

public class Television {

	static String comapny="MyCompany";
	static String model="LCD";
	static String info;
	
	static {
		info = comapny + "-" + model;
	}
	
	static void method() {
		
		
	}
}

package javaBasic3.ch06.sec09;

public class TelevisionExample {

	public static void main(String[] args) {
		
		System.out.println(Television.comapny);
		System.out.println(Television.model);
		System.out.println();
		System.out.println(Television.info);
	}

}

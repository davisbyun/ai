package javaBasic3.ch06.sec010.exam02;

import javaBasic3.ch06.sec010.exam03.ClassName250;

public class TelevisionExample {

	public static void main(String[] args) {
		System.out.println(Television.info);
		ClassName250 a = new ClassName250();
		a.method();
	}

}

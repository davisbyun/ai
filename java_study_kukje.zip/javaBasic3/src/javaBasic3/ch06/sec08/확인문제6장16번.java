package javaBasic3.ch06.sec08;

public class Ȯ�ι���6��16�� {

	public static void main(String[] args) {
//		Printer printer = new Printer();
//		printer.println(10);
//		printer.println(true);
//		printer.println(5.7);
//		printer.println("ȫ�浿");
		
		printer1.println(10);
		printer1.println(true);
		printer1.println(5.7);
		printer1.println("ȫ�浿");
	}

}

package javaBasic3.ch06.sec08;

public class Printer {

	public void println(boolean b) {
		System.out.println(b);
	}

	public void println(int i) {
		System.out.println(i);
		
	}

	public void println(double d) {
		System.out.println(d);
		
	}

	public void println(String string) {
		System.out.println(string);
		
	}
	
}

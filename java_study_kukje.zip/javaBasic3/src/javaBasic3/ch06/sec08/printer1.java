package javaBasic3.ch06.sec08;

public class printer1 {

	public static void println(boolean b) {
		System.out.println(b);
	}

	public static void println(int i) {
		System.out.println(i);
		
	}

	public static void println(double d) {
		System.out.println(d);
		
	}

	public static void println(String string) {
		System.out.println(string);
		
	}
	
	
	
}

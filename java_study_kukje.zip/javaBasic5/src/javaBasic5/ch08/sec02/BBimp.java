package javaBasic5.ch08.sec02;

public class BBimp implements BB {

	@Override
	public void aaM() {
	}

	@Override
	public void bbM() {
	}

	

	

}

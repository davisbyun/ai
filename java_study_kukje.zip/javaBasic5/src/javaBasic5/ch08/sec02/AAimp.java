package javaBasic5.ch08.sec02;

public class AAimp implements AA {

	@Override
	public void aaM() {
	}

	

}

package javaBasic5.ch08.sec02;

public class CCimp implements CC {

	@Override
	public void bbM() {
	}

	@Override
	public void aaM() {
	}

	@Override
	public void ccM() {
	}

	

	

}

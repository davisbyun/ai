package javaBasic5.ch08.sec02;

public interface CC extends BB {

	public void ccM();
}

package javaBasic5.ch08.sec02;

public interface AA {
	
	public void aaM();
	
}

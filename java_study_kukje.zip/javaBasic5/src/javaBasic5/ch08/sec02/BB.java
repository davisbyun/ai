package javaBasic5.ch08.sec02;

public interface BB extends AA {

	public void bbM();
}

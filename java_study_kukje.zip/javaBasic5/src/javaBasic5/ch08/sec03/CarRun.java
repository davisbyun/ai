package javaBasic5.ch08.sec03;

public class CarRun {

	void drive(Vehicle v) {
		v.run();
	}
}

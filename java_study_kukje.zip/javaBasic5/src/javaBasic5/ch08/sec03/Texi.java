package javaBasic5.ch08.sec03;

public class Texi implements Vehicle {

	@Override
	public void run() {
		System.out.println("�ýð� �޸��ϴ�.");
	}

}

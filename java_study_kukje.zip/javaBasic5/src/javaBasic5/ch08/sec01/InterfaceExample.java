package javaBasic5.ch08.sec01;

public class InterfaceExample {

	public static void main(String[] args) {
		
		

	}

}

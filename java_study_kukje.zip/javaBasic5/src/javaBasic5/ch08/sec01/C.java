package javaBasic5.ch08.sec01;

public interface C extends B {
	public void cM();
}

package javaBasic5.ch08.sec01;

public class CImpl implements C {

	@Override
	public void fly() {
	}

	@Override
	public void eat() {
	}

	@Override
	public void cM() {
	}

}

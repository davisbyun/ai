package javaBasic5.ch08.sec01;

public class AImpl implements A {

	@Override
	public void turnOn() {
	}

	@Override
	public void turnOff() {
	}

}

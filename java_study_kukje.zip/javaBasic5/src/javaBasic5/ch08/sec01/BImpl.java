package javaBasic5.ch08.sec01;

public class BImpl implements A, B {

	@Override
	public void fly() {
	}

	@Override
	public void eat() {
	}

	@Override
	public void turnOn() {
	}

	@Override
	public void turnOff() {
	}

}

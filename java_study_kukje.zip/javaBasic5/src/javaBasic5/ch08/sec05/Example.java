package javaBasic5.ch08.sec05;
/*
public class Example {

	public static void action(A a) {
		a.
			
	}

}



interface A {
	public void method1();

	public class B implements A {

	
		@Override
		public void method() {
			System.out.println("B -method1()");
		}
	
		public class C implements A {

		@Override
		public void method1() {
			System.out.println("C -method1()");
		}
		
		public void method2() {
			System.out.println("C -method2()");
		}
		
		public class Example {
			public static void action(A a) {
				
			}
		}

		
		}
		
		
	}
}
*/
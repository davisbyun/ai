package javaBasic6.ch09.sec06;

public interface RemoteControl {
	//�߻�޼ҵ�
	void turnOn();
	void turnOff();
}



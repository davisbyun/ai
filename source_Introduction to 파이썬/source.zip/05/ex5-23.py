names = ["황예린", "홍지수", "안지영"]
print(names)

x = "/".join(names)
print(x)

list1 = [3, 15, -12.5, "사과", "딸기"] 
print(list1)

list2 = list(range(1, 21, 2))
print(list2)

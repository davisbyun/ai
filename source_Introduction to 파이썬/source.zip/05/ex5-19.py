string1 = "Python is fun!"
print(string1)

x = string1.find("fun")
print(x)

sentences = ["Love me, love my dog.","No news is good news.",
             "Blood is thicker than water."]

for sentence in sentences :
    x = sentence.replace(" ", "_")
    print(x)

flowers = ["목련", "벚꽃", "장미", "백일홍"]
print(flowers)

flowers[1] = "무궁화"
print(flowers)

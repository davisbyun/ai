data = [12, 8, 15, 32, -3, -20, 15, 34, 6]
print(data)

data.sort()
print(data)

data.sort(reverse=True)
print(data)

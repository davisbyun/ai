scores = [80, 90, 85, 95, 100]

sm = sum(scores)
avg = sm/len(scores)

print("합계 :", sm)
print("평균 :", avg)
        
 
 
 

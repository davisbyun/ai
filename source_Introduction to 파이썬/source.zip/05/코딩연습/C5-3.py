data = list(range(1, 21))

i = 0
while i < len(data) :
    if (i+1)%2 == 1 :
        print("%d" % data[i], end=" ")

    i = i + 1


        
 
 
 

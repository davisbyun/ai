data = list(range(1, 21))

for i in range(0, len(data)) :
        print("%d" % data[i], end=" ")
 

data = list(range(1, 21))

for i in range(0, len(data)) :
    if (i+1)%2 == 0 :
        print("%d" % data[i], end=" ")
        
 
 

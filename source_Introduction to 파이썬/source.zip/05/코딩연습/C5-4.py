data = []

for x in range(10, 21) :
    data.append(x)

print(data)
        
 
 
 

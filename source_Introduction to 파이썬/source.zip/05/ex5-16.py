data = [10, 20, 30, 40, 50]
print(data)

data.reverse()
print(data)

colors = ["빨간색", "파란색", "노란색", "검정색", "초록색"]

for color in colors :
    print("나는 %s을 좋아한다" % color)

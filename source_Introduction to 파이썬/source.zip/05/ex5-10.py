number = [5, 20, 13, 7, 8, 22, 7, 17]
print(number)

idx = number.index(7)
print(idx)
 
 

animals = ["코끼리", "호랑이", "사슴", "펭귄", "여우"]

i = 0
while i < len(animals) :
    print(animals[i])

    i = i + 1

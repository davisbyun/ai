colors = ["빨간색", "파란색", "노란색", "검정색", "초록색"]

n = len(colors)
for i in range(0, n) :
    print("나는 %s을 좋아한다" % colors[i])

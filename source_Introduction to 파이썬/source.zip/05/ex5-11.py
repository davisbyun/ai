member = ["홍지웅", 20, "경기도 김포시", "jiwoong@naver.com", "010-1234-5678"]
print(member)

member.remove(20)
print(member)

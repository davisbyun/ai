data = [10, 20, 30, 40, 50, 60, 70, 80]
print(data)

x = data.pop(2)
print(x)
print(data)

x = data.pop(3)
print(x)
print(data)

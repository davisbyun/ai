string1 = "사과는 맛있다. 나는 사과를 제일 좋아한다."
print(string1)

x = string1.replace("사과", "딸기")
print(x)

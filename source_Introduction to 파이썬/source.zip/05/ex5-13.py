data = [3, 12, 7, -3, -9]
print(data)

data.clear()
print(data)
 
 
 

numbers = [7, 9, 15, 18, 30, -3, 7, 12, -16, -12]

sum = 0
i = 0
while i < len(numbers) :
    sum = sum + numbers[i]

    i = i + 1

print("합계 :", sum)

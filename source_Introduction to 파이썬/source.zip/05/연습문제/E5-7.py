numbers = [7, 9, 15, 18, 30, -3, 7, 12, -16, -12]

sum = 0

for number in numbers :
    sum = sum + number

print("합계 :", sum)

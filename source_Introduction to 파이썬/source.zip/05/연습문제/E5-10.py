fruits = ["사과", "오렌지", "딸기", "수박", "멜론"]

for i in range(len(fruits)) :
    print("%d. %s" % (i+1, fruits[i]))


string = "I am a genius!"

list1 = []
i = 0
while i < len(string) :
    list1.append(string[i])

    i = i + 1
    
print(list1)


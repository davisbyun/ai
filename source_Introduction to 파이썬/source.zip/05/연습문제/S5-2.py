emails = [["kim", "naver.com"], ["hwang", "hanmail.net"],
          ["lee", "korea.com"], ["choi", "gmail.com"]]

email_new = []
for email in emails :
    email_new.append(email[0] + "@" + email[1])

print(email_new)
    




# 정답 : ["f", "u", "n", "!"]

my_list = ["p","y","t","h","o","n","i","s","f","u","n","!"]

print(my_list[8:])


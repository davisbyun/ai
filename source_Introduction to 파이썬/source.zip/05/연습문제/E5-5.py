string = "I am a genius!"

list1 = []
for x in string :
    list1.append(x)
    
print(list1)


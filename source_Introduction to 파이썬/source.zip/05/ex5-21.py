phone1 = "010-3654-2637"
print(phone1)

phone2 = phone1.replace("-", "")
print(phone2)

arr = [5, 3, 12, 9, 2]
print(arr)

arr.append(10)
print(arr)
 

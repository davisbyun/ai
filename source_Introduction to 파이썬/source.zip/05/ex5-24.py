phone1 = ["010", "1234", "5678"]
print(phone1)

phone2 = "-".join(phone1)
print(phone2)  

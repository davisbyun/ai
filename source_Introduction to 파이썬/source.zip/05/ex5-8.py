scores = []

while True :
    score = int(input("성적을 입력하세요(종료 : -1): "))

    if score == -1 :
        break
    else :
        scores.append(score)

print(scores)
 
 

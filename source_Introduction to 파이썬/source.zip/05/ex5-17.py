fruits = ["apple", "banana", "orange"]
print(fruits)

x = fruits.copy()
print(x)

color = ["빨강", "주황", "노랑", "초록", "파랑", "남색", "보라"]

print(color[0])
print(color[5])
print(color[2:6])
print(color[-3])
print(color[-4:-1])

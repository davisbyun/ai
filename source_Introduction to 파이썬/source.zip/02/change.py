price = 3000
num = 3
pay = 10000

change = pay - price * num

print("거스름돈 --> %d원" % change) 

name = input("이름을 입력하세요 : ")
address = input("주소를 입력하세요 : ")
phone = input("전화번호를 입력하세요 : ")

print("- 이름 :", name)
print("- 주소 :", address)
print("- 전화번호 :", phone)

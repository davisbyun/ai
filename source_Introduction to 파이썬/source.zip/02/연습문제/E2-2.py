a = 10
b = 20

c = a + b

print("%d + %d = %d" % (a, b, c))


a = int(input("첫 번째 숫자를 입력하세요 : "))
b = int(input("두 번째 숫자를 입력하세요 : "))

c = a/b
print("%d / %d = %f" % (a, b, c))

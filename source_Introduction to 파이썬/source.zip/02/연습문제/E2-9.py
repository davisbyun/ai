email1 = input("이메일 주소 앞 부분은? ")
email2 = input("이메일 도메인 이름은? ")

email = email1 + "@" + email2

print("- 이메일 주소 :", email)

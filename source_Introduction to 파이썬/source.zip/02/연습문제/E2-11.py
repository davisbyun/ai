a = int(input("윗변의 길이는? "))
b = int(input("밑변의 길이는? "))
h = int(input("높이는? "))

area = (a + b) * h/ 2

print("- 사다리꼴의 면적 : %.1f" % area)

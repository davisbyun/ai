a = 10
b = 20

c = a + b

print(str(a) + " + " + str(b) + " = " + str(c))


num = input("열 자리의 숫자를 입력하세요 : ")

print("- 추출된 두 숫자 :", num[-2:])

a = 10
b = 20

c = a + b

print("두 수의 합 :", c)


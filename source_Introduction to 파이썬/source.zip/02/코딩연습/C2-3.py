r = float(input("반지름은? "))

length = 2 * 3.14 * r
area = r * r * 3.14

print("반지름 : %.2f cm" % r)
print("원의 둘레 : %.2f cm" % length)
print("원의 면적 : %.2f cm2" % area)



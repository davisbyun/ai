inch = float(input("인치는? "))

cm = inch * 2.54

print("%.1f inch => %.1f cm" % (inch, cm))



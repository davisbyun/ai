width  = int(input("사각형의 너비는? "))
height = int(input("사각형의 높이는? "))

length = 2 * width + 2 * height
area = width * height

print("사각형의 너비: %dcm" % width)
print("사각형의 높이 : %dcm" % height)
print("둘레 길이 : %dcm" % length)
print("면적 : %dcm2" % area)


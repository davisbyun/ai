year = input("년은? ")  
month = input("월은? ")  
day = input("일은? ")

print(year, month, day, sep=".")

age = int(input("당신의 나이는? "))

avg_age = 35

if age < avg_age :
    print("당신은 평균 나이(35세) 미만이다.")
else :
    print("당신은 평균 나이(35세) 이상이다.")
          

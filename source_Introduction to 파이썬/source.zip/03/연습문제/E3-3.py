num = input("숫자를 입력하세요 : ")

x = int(num[2])
if x%2 == 0 :
    print("%d은(는) 짝수이다." % x)
else :
    print("%d은(는) 홀수이다." % x)

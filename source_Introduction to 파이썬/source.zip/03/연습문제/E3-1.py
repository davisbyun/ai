num = int(input("숫자를 입력하세요 : "))

if num > 10 :
    print("%d은(는) 10보다 크다." % num)
else :
    print("%d은(는) 10보다 크지 않다." % num)    

x = int(input("양의 정수를 입력하세요: "))

if x%2 == 0 :
    print("짝수이다!")
else :
    print("홀수이다!")
    

ans1 = input("'사자'의 영어 단어는 무엇일까요? : ")   # 질문에 대한 답 입력
result = "땡! 틀렸습니다."              # 초기화
if ans1 == "lion" :                     # 정답 체크
    result = "딩동댕! 참 잘했어요~~~"   # 정답 메시지 입력    
print(result)                           # 화면에 결과 출력

ans2 = input("'오렌지'의 영어 단어는 무엇일까요? : ")
result = "땡! 틀렸습니다."
if ans2 == "orange" :
    result = "딩동댕! 참 잘했어요~~~"
print(result)

ans3 = input("'기차'의 영어 단어는 무엇일까요? : ")
result = "땡! 틀렸습니다."
if ans3 == "train" :
    result = "딩동댕! 참 잘했어요~~~"
print(result)
    

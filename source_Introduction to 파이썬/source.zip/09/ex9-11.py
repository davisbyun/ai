import math

print("floor(12.3) :", math.floor(12.3))
print("floor(12.7) :", math.floor(12.7))
print("floor(-25.2) :", math.floor(-25.2))
print("floor(-25.8) :", math.floor(-25.8))

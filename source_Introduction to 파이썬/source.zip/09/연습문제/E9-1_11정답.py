"""
9장 1번 ~ 10번 정답

E9-1. 36 36

E9-2. 7 -9

E9-3. 24 -12

E9-4. 16.0 0.04

E9-5. time.time()

E9-6. time.localtime()

E9-7. time.sleep()

E9-8. datetime.now()

E9-9. random.random()

E9-10. random.choice()

E9-11. sleep(), random.randint, random.randint
"""


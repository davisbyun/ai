import random

print("randint(1, 6) :", random.randint(1, 6))
print("randint(1, 6) :", random.randint(1, 6))


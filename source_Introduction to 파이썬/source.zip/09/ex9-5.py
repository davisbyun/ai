import calc as c

x = c.add(100, 10)
print(x)

y = c.sub(100, 10)
print(y)
    

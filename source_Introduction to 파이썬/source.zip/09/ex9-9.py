import math

print("tan(2) :", math.tan(2))
print("tan(-2) :", math.tan(-2))
print("tan(0) :", math.tan(0))
print("tan(pi/4) :", math.tan(math.pi/4))

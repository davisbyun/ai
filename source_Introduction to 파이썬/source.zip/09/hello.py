def greet1(name) :
    print(name + "님 안녕하세요.")

def greet2(name) :
    print(name + "님 반갑습니다.")


    

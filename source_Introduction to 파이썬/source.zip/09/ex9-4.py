import calc

x = calc.add(10, 20)
print(x)

y = calc.sub(10, 20)
print(y)


    

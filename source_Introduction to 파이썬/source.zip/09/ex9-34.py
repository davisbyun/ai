import random
import time

print("two dice are rolling ...")
time.sleep(2)

me = random.randint(1, 6)
computer = random.randint(1, 6)
print("나 :", me)
print("컴퓨터 :", computer)



import hello

hello.greet1("홍지수")
hello.greet2("안지영")





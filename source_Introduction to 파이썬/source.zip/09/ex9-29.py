import random

print("uniform(1, 10) :", random.uniform(1, 10))
print("uniform(1, 10) :", random.uniform(1, 10))


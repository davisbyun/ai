from calc import add, sub

x = add(100, 200)
print(x)

y = sub(100, 200)
print(y)
    

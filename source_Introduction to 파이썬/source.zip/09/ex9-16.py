import math

print("sqrt(25) :", math.sqrt(25))
print("sqrt(2) :", math.sqrt(2))
print("sqrt(pi) :", math.sqrt(math.pi))


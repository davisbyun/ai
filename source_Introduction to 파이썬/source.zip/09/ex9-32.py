import random

list1 = [15, 23, 4, 88, 7]
print("원래의 리스트 :", list1)

random.shuffle(list1)
print("순서가 변경된 리스트 :", list1)


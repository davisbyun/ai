def add(a, b) :
    c = a + b
    return c

def sub(a, b) :
    c = a - b
    return c

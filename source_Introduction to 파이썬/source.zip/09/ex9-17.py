import time

seconds = time.time()
print(seconds)

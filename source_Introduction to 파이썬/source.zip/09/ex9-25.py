import datetime

today = datetime.date.today()
print(today)

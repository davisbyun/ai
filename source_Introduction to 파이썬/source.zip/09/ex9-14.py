import math

print("log(75.3) :", math.log(75.3))
print("log(pi) :", math.log(math.pi))
print("log10(75.3) :", math.log10(75.3))
print("log10(pi) :", math.log10(math.pi))

print("round(12.3) :", round(12.3))
print("round(12.7) :", round(12.7))
print("round(-25.2) :", round(-25.2))
print("round(-25.8) :", round(-25.8))

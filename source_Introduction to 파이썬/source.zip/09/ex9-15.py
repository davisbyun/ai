import math

print("pow(5, 2) :", math.pow(5, 2))
print("pow(100, -2) :", math.pow(100, -2))
print("pow(3, 0) :", math.pow(3, 0))

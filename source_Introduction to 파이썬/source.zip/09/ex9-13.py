import math

print(math.fsum([1, 2, 3, 4, 5]))
print(math.fsum([1.7, 0.3, 1.5, 4.5]))
print(math.fsum((10, 20, 30, 40, 50)))

import math

print("ceil(12.3) :", math.ceil(12.3))
print("ceil(12.7) :", math.ceil(12.7))
print("ceil(-25.2) :", math.ceil(-25.2))
print("ceil(-25.8) :", math.ceil(-25.8))

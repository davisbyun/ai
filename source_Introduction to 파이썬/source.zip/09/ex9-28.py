import random

print("random() :", random.random())
print("random() :", random.random())


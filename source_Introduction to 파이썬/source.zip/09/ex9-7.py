import math

print("sin(2) :", math.sin(2))
print("sin(-2) :", math.sin(-2))
print("sin(0) :", math.sin(0))
print("sin(pi/2) :", math.sin(math.pi/2))

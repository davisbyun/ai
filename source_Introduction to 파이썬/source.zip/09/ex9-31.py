import random

print("choice([1, 2, 3, 4, 5, 6]) :", random.choice([1, 2, 3, 4, 5, 6]))
print("choice([1, 2, 3, 4, 5, 6]) :", random.choice([1, 2, 3, 4, 5, 6]))
print("choice('python') :", random.choice("python"))
print("choice('python') :", random.choice("python"))

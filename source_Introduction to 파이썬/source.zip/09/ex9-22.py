import time

print("시작!")
time.sleep(5)
print("5초 후 나타남!")

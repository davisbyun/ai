import math

print("cos(2) :", math.cos(2))
print("cos(-2) :", math.cos(-2))
print("cos(0) :", math.cos(0))
print("cos(2*pi) :", math.cos(2*math.pi))

for i in range(9, 0, -1) :
    for j in range(i) :
        print(i, end=" ")
    print()

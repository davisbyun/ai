for i in range(10) :
    print("*" * (10-i), end="")
    print()

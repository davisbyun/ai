fact = 1
for i in range(1, 10) :
        fact = fact * i
        
print("10! =", fact)

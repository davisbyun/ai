sum = 0
for i in range(1, 101) :
    if i%4 == 0 :
        sum = sum + i
        
        print(i, "-->", sum)

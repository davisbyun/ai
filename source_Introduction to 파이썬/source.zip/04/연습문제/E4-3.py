for i in range(1, 101) :
    if i%5 == 0 :
        print(i, end=" ")



fact = 1
i = 1

while i < 11 :
   fact = fact * i

   i = i + 1
        
print("10! =", fact)

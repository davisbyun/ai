for x in range(5) :			# x가 0~4의 값을 가지고 5번 반복
    print("안녕하세요!")

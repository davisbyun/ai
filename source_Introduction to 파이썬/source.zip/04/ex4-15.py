for i in range(1, 1001) :
    print(i)

    if i == 10 :
        break

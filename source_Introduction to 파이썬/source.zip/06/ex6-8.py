user = {"id":"kim55", "name":"강성준", "level":7, "point":10000}

print(user)
print(user["id"])
print(user["name"])
print(user["point"])



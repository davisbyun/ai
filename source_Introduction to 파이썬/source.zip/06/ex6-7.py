member = {"name": "황예린", "age": 22, "email": "yerin@hanmail.net"}
print(member)

score = dict([("국어", 80), ("영어", 90), ("수학", 100)])
print(score)




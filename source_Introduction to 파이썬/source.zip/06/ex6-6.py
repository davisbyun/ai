admin_info = ("admin", "12345", "webmaster@naver.com")

print("관리자 정보")
print("아이디 : " + admin_info[0])
print("비밀번호 : " + admin_info[1])
print("이메일 : " + admin_info[2])


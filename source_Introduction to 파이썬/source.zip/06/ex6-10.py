words = {"door": "문", "chair": "의자", "table": "책상", "house": "집"}
print(words)

words["table"] = "테이블"
print(words)

words["house"] = "하우스"
print(words)

car = {"brand":"현대",  "model":"아반떼", "start":1990, "year":2021}
print(car)

x = car.pop("start")
print(x)

print(car)

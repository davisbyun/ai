scores = {"kor": 90, "eng": 89, "math": 98}
print(scores)

scores["music"] = 100
print(scores)
 


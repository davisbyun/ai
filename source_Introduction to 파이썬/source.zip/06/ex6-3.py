n = tuple(range(10, 21))
print(n)

print("n[0] =", n[0])
print("n[2:5] =", n[2:5])
print("n[2:] =", n[2:])
print("n[:5] =", n[:5])
print("n[-2] =", n[-2])
print("n[::-1] =", n[::-1])

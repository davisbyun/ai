tup1 = (10, 20, 30, 40, 50)

for i in range(len(tup1)) :	#  len(tup1) : tup1의 길이
    print(tup1[i])


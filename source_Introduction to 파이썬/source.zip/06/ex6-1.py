animals = ("토끼", "거북이", "사자", "여우")
print(animals)

numbers = tuple(range(10))
print(numbers)

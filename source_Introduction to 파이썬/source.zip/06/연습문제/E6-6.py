# 정답 : 5
person = {"name":"홍길동", "age":30, "family":5, "children":["선미","성진","소영"],
          "pets":["강아지", "고양이", "이구아나"]}

print(len(person))



 

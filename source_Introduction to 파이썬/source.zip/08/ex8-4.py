x = max(3, 5, 2)
print(x)

data = [3, 7, 2, 12, 6]
y = max(data)
print(y)

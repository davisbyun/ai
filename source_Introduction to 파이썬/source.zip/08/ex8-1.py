x = "1"

print("아스키 코드 :", ord(x))

x = round(7.65676)
print(x)

y = round(7.65676, 2)
print(y)

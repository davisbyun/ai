x = "a"
code = ord(x)

print("아스키 코드(10진수) : %d" % code) 
print("아스키 코드(16진수) : %s" % hex(code))
print("아스키 코드(2진수) : %s" % bin(code))

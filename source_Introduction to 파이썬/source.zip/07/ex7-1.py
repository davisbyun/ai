def hello() :
    print("안녕하세요!")

hello()
hello()
hello()

def func(food):
  for x in food:
    print(x)

fruits = ["사과", "오렌지", "바나나"]

func(fruits)

    

    


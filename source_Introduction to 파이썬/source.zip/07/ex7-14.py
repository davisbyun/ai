def func() : 
    print(x)

x = 100         
func()
print(x)

 

    
    
    

def add(a, b) :
    c = a + b
    print("%d + %d = %d" % (a, b, c))
                
add(12, 15)
add(245, 300)
add(-38, -12)
    

    


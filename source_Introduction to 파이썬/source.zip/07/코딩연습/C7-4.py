def multiply(num, x) :
    i = 0
    while i< len(num) :
        num[i] = num[i] * x

        i= i + 1
        
numbers = [10,20,30,40,50]
 
multiply(numbers, 10)
print(numbers)

multiply(numbers,10)
print(numbers)

    

    


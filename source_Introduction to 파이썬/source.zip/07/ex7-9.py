def func(food):
    food.append("딸기")
    food.append("수박")
    
fruits = ["사과", "오렌지", "바나나"]

print(fruits)
func(fruits)
print(fruits)

    

    


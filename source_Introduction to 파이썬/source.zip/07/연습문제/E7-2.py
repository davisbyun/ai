"""
- 프로그램 실행 결과 :
200
100
"""
def func() :
    x = 200
    print(x)

x = 100
func()
print(x)

    

    


def func() :
    x = 200

func()
print(x)

    

    


def func(n) :
    x = n + 5
    return x

a = func(10)
print(a)
b = func(20)
print(b)




    
    
    

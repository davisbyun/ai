def print_name(first_name, last_name) :
    name = first_name + last_name
    print("이름 :", name)

print_name("홍", "정원")


    
    
    

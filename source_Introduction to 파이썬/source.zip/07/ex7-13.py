def func() :
    x = 100
    print(x)
                
func()
print(x)



    
    
    

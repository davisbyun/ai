class Person :
    def hello(self) :
        print("안녕하세요.")

person1 = Person()
person1.hello()

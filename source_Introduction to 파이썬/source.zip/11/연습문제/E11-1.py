# 정답 : 30
class Calculator :
    a = 10
    b = 20

    def add(self) :
        return self.a + self.b

c1 = Calculator()
print(c1.add())


import os

if os.path.exists("test"):
  os.rmdir("test")
else:
  print("폴더가 존재하지 않음!")







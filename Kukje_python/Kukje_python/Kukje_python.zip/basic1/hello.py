name = "김콩쥐"
addr = "부산시 해운대구"
tel = "010-1234-5678"
email = "book@inforbook.com"

print(name)
print(addr)
print(tel)
print(email)
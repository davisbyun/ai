name = "홍길동"
age = 30
job="python programmer"
print( name, age,  job) 